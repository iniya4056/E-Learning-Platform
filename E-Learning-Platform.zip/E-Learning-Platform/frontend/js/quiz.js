let course = (localStorage.getItem("courseName") || "").trim();

/* ---------------- QUESTION BANK ---------------- */

let questionBank = {
  "Programming in C": [
    { q: "Who developed C language?", options: ["Dennis Ritchie","Bjarne Stroustrup","James Gosling","Guido van Rossum"], answer: 0 },
    { q: "C is a ____ language", options: ["High level","Low level","Middle level","AI level"], answer: 2 },
    { q: "Which symbol ends a statement?", options: [".",":",";","/"], answer: 2 },
    { q: "Header file extension?", options: [".h",".c",".cpp",".java"], answer: 0 },
    { q: "printf function is used for?", options: ["Input","Output","Compile","Run"], answer: 1 }
  ],

  "OOP using C++": [
    { q: "C++ is developed by?", options: ["Dennis Ritchie","Bjarne Stroustrup","James Gosling","Guido"], answer: 1 },
    { q: "OOP stands for?", options: ["Object Oriented Programming","Only Object Process","Order Oriented","None"], answer: 0 },
    { q: "Constructor is called when?", options: ["Object created","Class deleted","Compile time","Run end"], answer: 0 },
    { q: "Inheritance means?", options: ["Reuse","Delete","Compile","Loop"], answer: 0 },
    { q: "C++ supports?", options: ["OOP","POP only","Only scripting","None"], answer: 0 }
  ],

  "Data Structures": [
    { q: "Stack follows?", options: ["FIFO","LIFO","Random","Tree"], answer: 1 },
    { q: "Queue follows?", options: ["FIFO","LIFO","Graph","Sort"], answer: 0 },
    { q: "Linked list is?", options: ["Linear","Non-linear","Tree","Graph"], answer: 0 },
    { q: "Binary tree max children?", options: ["1","2","3","4"], answer: 1 },
    { q: "Array index starts from?", options: ["1","0","-1","2"], answer: 1 }
  ],

  "DBMS": [
    { q: "DBMS stands for?", options: ["Database System","Database Management System","Data Base Main","None"], answer: 1 },
    { q: "SQL used for?", options: ["Styling","Query","Gaming","OS"], answer: 1 },
    { q: "Primary key is?", options: ["Unique","Duplicate","Null","Random"], answer: 0 },
    { q: "DBMS stores data in?", options: ["Files","Tables","Images","Code"], answer: 1 },
    { q: "Foreign key is used for?", options: ["Link tables","Delete","Compile","Run"], answer: 0 }
  ],

  "Operating Systems": [
    { q: "OS acts as?", options: ["Interface","Compiler","Hardware","Virus"], answer: 0 },
    { q: "Example of OS?", options: ["Windows","Chrome","Word","Excel"], answer: 0 },
    { q: "Process means?", options: ["Program in execution","File","Folder","Virus"], answer: 0 },
    { q: "Kernel is?", options: ["Core of OS","App","Game","Driver"], answer: 0 },
    { q: "Multitasking means?", options: ["Multiple tasks","One task","Delete task","None"], answer: 0 }
  ],

  "Computer Networks": [
    { q: "LAN stands for?", options: ["Local Area Network","Large Area Network","Link Area","None"], answer: 0 },
    { q: "IP stands for?", options: ["Internet Protocol","Internal Program","IP Address only","None"], answer: 0 },
    { q: "Router is used for?", options: ["Routing data","Gaming","Compile","Storage"], answer: 0 },
    { q: "HTTP is?", options: ["Protocol","Software","Hardware","Game"], answer: 0 },
    { q: "WWW stands for?", options: ["World Wide Web","Web Work","Wide Web World","None"], answer: 0 }
  ],

  "Web Technologies": [
    { q: "HTML stands for?", options: ["Hyper Text Markup Language","High Text","Home Tool","None"], answer: 0 },
    { q: "CSS used for?", options: ["Styling","Logic","Database","OS"], answer: 0 },
    { q: "JS used for?", options: ["Logic","Design","DB","OS"], answer: 0 },
    { q: "HTML tag for link?", options: ["<a>","<p>","<div>","<img>"], answer: 0 },
    { q: "Frontend runs on?", options: ["Browser","Server","Database","CPU"], answer: 0 }
  ],

  "Software Engineering": [
    { q: "SDLC means?", options: ["Software Dev Life Cycle","System Design","Simple Dev","None"], answer: 0 },
    { q: "Requirement analysis is?", options: ["First stage","Last stage","Testing","Coding"], answer: 0 },
    { q: "Testing is used for?", options: ["Find bugs","Design","Plan","Deploy"], answer: 0 },
    { q: "Agile is?", options: ["Model","Language","Tool","OS"], answer: 0 },
    { q: "Waterfall is?", options: ["Model","Tool","DB","OS"], answer: 0 }
  ],

  "Artificial Intelligence": [
    { q: "AI stands for?", options: ["Artificial Intelligence","Auto Input","Advanced Internet","None"], answer: 0 },
    { q: "AI used for?", options: ["Smart systems","OS","DB","HTML"], answer: 0 },
    { q: "ML is part of?", options: ["AI","DB","OS","Network"], answer: 0 },
    { q: "ChatGPT is?", options: ["AI model","Browser","Game","OS"], answer: 0 },
    { q: "AI learns from?", options: ["Data","Code","HTML","CSS"], answer: 0 }
  ],

  "Machine Learning": [
    { q: "ML stands for?", options: ["Machine Learning","Main Logic","Math Level","None"], answer: 0 },
    { q: "ML uses?", options: ["Data","Only code","OS","HTML"], answer: 0 },
    { q: "Supervised learning uses?", options: ["Labeled data","No data","OS","Network"], answer: 0 },
    { q: "Unsupervised means?", options: ["No labels","Labels","Code","OS"], answer: 0 },
    { q: "ML output improves with?", options: ["More data","Less data","No data","Bug"], answer: 0 }
  ]
};

/* ---------------- SAFE COURSE MATCH ---------------- */

course = Object.keys(questionBank).find(c => c === course);
let questions = course ? questionBank[course] : [];

let current = 0;
let score = 0;

/* ---------------- INIT ---------------- */

loadQuestion();

/* ---------------- LOAD QUESTION ---------------- */

function loadQuestion(){

    if(questions.length === 0){
        document.getElementById("quizBox").innerHTML =
            "<h2>No Quiz Available</h2>";
        return;
    }

    let q = questions[current];

    document.getElementById("question").innerText = q.q;

    document.getElementById("opt0").innerText = q.options[0];
    document.getElementById("opt1").innerText = q.options[1];
    document.getElementById("opt2").innerText = q.options[2];
    document.getElementById("opt3").innerText = q.options[3];
}

/* ---------------- ANSWER ---------------- */

function selectAnswer(index){
    if(index === questions[current].answer){
        score++;
    }
    nextQuestion();
}

/* ---------------- NEXT ---------------- */

function nextQuestion(){

    current++;

    if(current < questions.length){
        loadQuestion();
    } else {
        showResult();
    }
}

/* ---------------- RESULT ---------------- */

function showResult(){

    document.getElementById("quizBox").style.display = "none";

    document.getElementById("nextBtn").style.display = "none";

    let status = (score >= 3) ? "PASS " : "FAIL ";

    document.getElementById("result").innerHTML =
    `
    Score: ${score}/${questions.length}
    <br>Status: ${status}
    <br><br>
    <button class="save-btn" onclick="saveResult()">
        Save Result
    </button>
    `;
}

/* ---------------- SAVE RESULT ---------------- */

function saveResult(){

    localStorage.setItem("score", score);
    localStorage.setItem("total", questions.length);
    localStorage.setItem("courseName", course);

    fetch("http://127.0.0.1:5000/save-result", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            userName: localStorage.getItem("userName"),
            courseName: course,
            score: score,
            total: questions.length
        })
    })
    .then(res => res.text())
    .then(data => {
        alert(data);

        if(score >= 3){
            window.location.href = "certificate.html";
        }
    })
    .catch(err => console.log(err));
}