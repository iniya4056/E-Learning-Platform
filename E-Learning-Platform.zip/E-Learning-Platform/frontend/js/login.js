function loginUser() {

    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value.trim();

    if (!email || !password) {
        alert("Please enter email and password");
        return;
    }

    fetch("http://127.0.0.1:5000/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: email,
            password: password
        })
    })
    .then(res => res.json())
    .then(data => {

        console.log("LOGIN RESPONSE:", data);

        if (data.message === "Login Success") {

            alert("Login Successful");

            localStorage.setItem(
                "userName",
                data.user.name
            );

            localStorage.setItem(
                "userEmail",
                data.user.email
            );

            window.location.href = "dashboard.html";

        } else {

            alert(data.message || "Invalid Credentials");

        }
    })
    .catch(error => {

        console.error("LOGIN ERROR:", error);

        alert("Cannot connect to server");

    });
}