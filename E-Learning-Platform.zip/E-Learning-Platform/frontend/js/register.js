console.log("REGISTER JS LOADED");

function registerUser() {

    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    fetch("http://127.0.0.1:5000/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, email, password })
    })
    .then(res => res.text())
    // .then(data => alert(data))
    .then(data => {
    alert(data);
    window.location.href = "login.html";
})
    .catch(err => alert("Server Error"));
}