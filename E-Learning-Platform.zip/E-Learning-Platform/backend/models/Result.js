const mongoose = require("mongoose");

const ResultSchema = new mongoose.Schema({
    userName: String,
    courseName: String,
    score: Number,
    total: Number,
    status: String,
    date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("Result", ResultSchema);