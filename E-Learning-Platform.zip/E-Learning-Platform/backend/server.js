const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const User = require("./models/User");
const Result = require("./models/Result");

const app = express();   

/* MIDDLEWARE */
app.use(cors({
    origin: "*"
}));

app.use(express.json());

/* TEST */
app.get("/", (req, res) => {
    res.send("Backend Running");
});

app.get("/test", (req, res) => {
    res.send("BACKEND WORKING");
});

/* MONGODB */
mongoose.connect("mongodb+srv://iniyaa_db_user:iniya3545@cluster0.gobke6t.mongodb.net/lms?appName=Cluster0")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

/* REGISTER */
app.post("/register", async (req, res) => {
    try {
        console.log("REGISTER HIT:", req.body);

        const { name, email, password } = req.body;

        // Check empty fields
        if (!name || !email || !password) {
            return res.status(400).json({
                message: "Please fill all fields"
            });
        }

        // Check existing user
        const exist = await User.findOne({ email });

        if (exist) {
            return res.status(400).json({
                message: "User already exists"
            });
        }

        // Create new user
        const user = new User({
            name: name,
            email: email,
            password: password
        });

        // Save to MongoDB
        await user.save();

        console.log("USER SAVED:", user);

        res.status(201).json({
            message: "User Registered Successfully"
        });

    } catch (err) {

        console.log("REGISTER ERROR:", err);

        res.status(500).json({
            message: "Register Error",
            error: err.message
        });
    }
});

/* LOGIN */
app.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        console.log("LOGIN HIT:", email);

        const user = await User.findOne({
            email: email,
            password: password
        });

        if (!user) {
            return res.status(401).json({
                message: "Invalid Credentials"
            });
        }

        console.log("LOGIN SUCCESS:", user.email);

        res.status(200).json({
            message: "Login Success",
            user: {
                name: user.name,
                email: user.email
            }
        });

    } catch (err) {
        console.log("LOGIN ERROR:", err);

        res.status(500).json({
            message: "Login Error"
        });
    }
});
/* RESULT */
app.post("/save-result", async (req, res) => {
    try {
        const result = new Result(req.body);
        await result.save();
        res.send("Saved");
    } catch (err) {
        res.send("Error");
    }
});

app.listen(5000, () => {
    console.log("Server Running on Port 5000");
});